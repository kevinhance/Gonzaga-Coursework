#ifndef LINKEDLIST_H
#define LINKEDLIST_H

using namespace std;

struct LinkedNode {
	LinkedNode *next;
	int data;
};

template<class ListDataType>
class LinkedList {
public:
	// Create an empty linked list
	LinkedList(){
	head = nullptr;
}

	// Deallocates all items in this list
	~LinkedList(){
	while (head) {
		LinkedNode *tmp = head;
		head = head->next;
		delete tmp;
	}
}

	// Adds a new item to the beginning of the list
	void addFront(ListDataType item){
	LinkedNode *node = new LinkedNode;
	node->data = item;
	node->next = head;
	head = node;
}


	// Adds a new item to the end of the list
	void addBack(ListDataType item){
	LinkedNode *node = new LinkedNode;
	node->next = nullptr;
	node->data = item;
	if (head) {
		LinkedNode *p = head;
		while (p->next) {
			p = p->next;
		}
		p->next = node;
	} else {
		head = node;
	}
}

	// Removes the first element of the list and then returns it
	ListDataType popFront(){
	// It is an error if pop is called on an empty list
	assert(head);
	ListDataType answer = head->data;
	LinkedNode *tmp = head;
	head = head->next;
	delete tmp;
	return answer;
}

	// Removes the last element of the list and then returns it
	ListDataType popBack(){
	// It is an error if pop is called on an empty list
	assert(head);

	// If head is the only node, we need to delete that and set
	// head to be null
	if (!head->next) {
		ListDataType answer = head->data;
		delete head;
		head = nullptr;
		return answer;
	}

	// Otherwise, we need to find a node that lacks a next pointer, and
	// set the pointer to THAT node to be null.
	LinkedNode *node = head;
	while (node->next->next) {
		node = node->next;
	}
	ListDataType answer = node->next->data;
	delete node->next;
	node->next = nullptr;
	return answer;
}

	// Returns the size of the list
	ListDataType size() {
	ListDataType count = 0;
	LinkedNode *node = head;
	while (node) {
		count++;
		node = node->next;
	}
	return count;
}

	// Returns a count of the number of items equal to the passed-in item
	ListDataType itemCount(ListDataType item){
	ListDataType count = 0;
	LinkedNode *node = head;
	while (node) {
		if (node->data == item) {
			count++;
		}
		node = node->next;
	}
	return count;
}

	// Displays the list on cout with items separated by spaces
	void display(){
	cout << "List: ";
	LinkedNode *node = head;
	while (node) {
		cout << node->data << " ";
		node = node->next;
	}
	cout << endl << endl;
}
private:
	LinkedNode *head;
};

#endif
