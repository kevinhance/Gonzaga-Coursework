#ifndef LINKEDLIST_H
#define LINKEDLIST_H

struct LinkedNode {
	LinkedNode *next;
	int data;
};

class LinkedList {
public:
	// Create an empty linked list
	LinkedList();

	// Deallocates all items in this list
	~LinkedList();

	// Adds a new item to the beginning of the list
	void addFront(int item);

	// Adds a new item to the end of the list
	void addBack(int item);

	// Removes the first element of the list and then returns it
	int popFront();

	// Removes the last element of the list and then returns it
	int popBack();

	// Returns the size of the list
	int size();

	// Returns a count of the number of items equal to the passed-in item
	int itemCount(int item);

	// Displays the list on cout with items separated by spaces
	void display();
private:
	LinkedNode *head;
};

#endif
